<?php

namespace Database\Factories;

use App\Models\CharactersList;
use Illuminate\Database\Eloquent\Factories\Factory;

class CharactersListFactory extends Factory
{
    protected $model = CharactersList::class;

    public function definition(): array
    {
    	return [
    	    //
    	];
    }
}
